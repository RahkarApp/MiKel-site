# MiKel-dsajfkljasdkfljalsk



## Shared project design reference

Read [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) for the complete extracted design system. Project chats and agents should follow [AGENTS.md](AGENTS.md).
